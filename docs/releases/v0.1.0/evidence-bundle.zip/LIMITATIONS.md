# Limitations

This bundle is generated from a deterministic demonstration baseline. It is not validated for production, safety, or shop-floor release decisions.
